﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

	public Transform target;
	public float smoothing = 5f;
	public float speed = 6f;
	Vector3 offset;
	//public float horizontalSpeed = 1.0f;

	void Start() {
		offset = transform.position - target.position;
	}

	void FixedUpdate(){
		Vector3 targetCamPos = target.position + offset;
		transform.position = Vector3.Lerp (transform.position, targetCamPos, smoothing * Time.deltaTime);
		//WOrks just need to fix better later
		//float hl = horizontalSpeed * Input.GetAxis ("Mouse X");
		//transform.Rotate (0, hl, 0);
	}


}
