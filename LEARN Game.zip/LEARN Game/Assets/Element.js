﻿#pragma strict
var myHydrogens: GameObject[];
var hydrogen_ANIMATION_Lianne : GameObject;
var originalPositions:Vector3[];

//code achieved with help from Sabine Rosenberg in Computation Lab

function Start () {
	for (var i = 0; i <10; i++) {
	var myHydrogen = Instantiate(hydrogen_ANIMATION_Lianne, Vector3(Random.Range(-5,25),0,Random.Range(0,80)), Quaternion.identity);
	myHydrogens[i] = myHydrogen;

	originalPositions[i] = Vector3(myHydrogen.transform.position.x,
	myHydrogen.transform.position.y,
	myHydrogen.transform.position.z);


	}
}

function Update () {

    for (var i = 0; i<10; i++) {

    myHydrogens[i].transform.Translate(Vector3(Random.Range(-1,1), 0, Random.Range(-1, 1))*Time.deltaTime);

    }
}
