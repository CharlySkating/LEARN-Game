﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//the following player movement came from the Unity tutorial "Player Character - Survival Shooter Tutorial"
//Unity.(2014 October 14). Survival shooter tutorial - 2 of 10: Player character- Unity official tutorials(new)[Video file].
//Retrieved from https://www.youtube.com/watch?v=R8O8Y6xP79w

public class PlayerMOvement : MonoBehaviour {

	public float speed = 6f;
	public int counter = 0;

	Vector3 movement;
	Rigidbody playerRigidbody;


	void Awake() {
		
		playerRigidbody = GetComponent<Rigidbody> ();
	}


	void FixedUpdate() {
		float h = Input.GetAxisRaw ("Horizontal");
		float v = Input.GetAxisRaw ("Vertical");

		Move (h, v);
		Turning ();
	}

	void Move (float h, float v) {
		movement.Set (h, 0f, v);
		movement = movement.normalized * speed * Time.deltaTime;
		playerRigidbody.MovePosition (transform.position + movement);
	}

	void Turning () {
		Plane playerPlane = new Plane (Vector3.up, transform.position);
		Ray camRay = Camera.main.ScreenPointToRay (Input.mousePosition);
		float hitdist = 0.0f;
		//Causes player to follow mouse
		if (playerPlane.Raycast (camRay, out hitdist)) {
			Vector3 targetPoint = camRay.GetPoint (hitdist);
			Quaternion targetRotation = Quaternion.LookRotation (targetPoint - transform.position);
			transform.rotation = Quaternion.Slerp (transform.rotation, targetRotation, speed * Time.deltaTime);
		}
	}//End of character tutorial

	void OnCollisionEnter (Collision col){

		if (col.gameObject.name == "fixedPrefabnewnew(Clone)") {
			//Debug.Log ("hit");
			Destroy (col.gameObject);
			counter++;
		}
		if (counter == 2) {
			StartNewLevel ();
		}
	}

		void OnGUI() {
			//if (counter == 2) {
				//Debug.Log ("Time to make some bonds");
		GUI.Label(new Rect(10,10,100,20), counter.ToString());
		}

	void StartNewLevel() {
		Debug.Log ("Start level");
		Application.LoadLevel ("Making_Bonds");
	}

}
