﻿#pragma strict
var myElement : GameObject;


function Start () {


	}

function Update () {

	transform.RotateAround (myElement.transform.position, Vector3.up, 100*Time.deltaTime);

}
